import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TransactionService } from '../services/transaction-service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.page.html',
  styleUrls: ['./transaction.page.scss'],
  standalone: false,
})
export class TransactionPage {

  constructor(
    public transactionservice: TransactionService,
    private router: Router
  ) { }

  viewDetail(id: number) {
    this.router.navigate(['/transaction-detail', id]);
  }

}

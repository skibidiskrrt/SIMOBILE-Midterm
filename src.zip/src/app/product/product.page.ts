import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AnimationController } from '@ionic/angular/lazy';
import { ProductService } from '../services/product-service';
import { CartService } from '../services/cart-service';


@Component({
  selector: 'app-product',
  templateUrl: './product.page.html',
  styleUrls: ['./product.page.scss'],
  standalone: false,
})
export class ProductPage implements OnInit {

  products: any[] = [];
  filteredProducts: any[] = [];
  searchText: string = '';

  constructor(
    private productservice: ProductService,
    private router: Router,
    public cartservice: CartService,
    private animationCtrl: AnimationController
  ) { }

  ngOnInit() {
    this.products = this.productservice.products;
    this.filteredProducts = this.products;
  }

  deleteProduct(id: number) {
    this.productservice.products =
      this.productservice.products.filter(product => product.id !== id);

    this.filteredProducts = this.productservice.products;
  }

  searchProducts() {
    this.filteredProducts = this.products.filter(product =>
      product.name.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  viewDetail(id: number) {
    this.router.navigate(['/product-detail', id]);
  }

  addToCart(product: any) {
    if (this.cartservice.add(product)) {
      // feedback animation: the cart button pops
      const cartButton = document.querySelector('#cartButton') as HTMLElement;
      this.animationCtrl
        .create()
        .addElement(cartButton)
        .duration(300)
        .keyframes([
          { offset: 0, transform: 'scale(1)' },
          { offset: 0.5, transform: 'scale(1.4)' },
          { offset: 1, transform: 'scale(1)' },
        ])
        .play();
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AnimationController } from '@ionic/angular/lazy';
import { ProductService } from '../services/product-service';
import { CartService } from '../services/cart-service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.page.html',
  styleUrls: ['./product-detail.page.scss'],
  standalone: false,
})
export class ProductDetailPage implements OnInit {

  product: any;

  constructor(
    private route: ActivatedRoute,
    private productservice: ProductService,
    private cartservice: CartService,
    private animationCtrl: AnimationController
  ) { }

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.product = this.productservice.products.find(
      product => product.id === id
    );
  }
  addToCart(product: any) {
    if (this.cartservice.add(product)) {
      // feedback animation: the button pops
      const button = document.querySelector('#addToCartButton') as HTMLElement;
      this.animationCtrl
        .create()
        .addElement(button)
        .duration(300)
        .keyframes([
          { offset: 0, transform: 'scale(1)' },
          { offset: 0.5, transform: 'scale(1.2)' },
          { offset: 1, transform: 'scale(1)' },
        ])
        .play();
    }
  }

}
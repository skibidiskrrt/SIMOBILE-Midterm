import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AnimationController } from '@ionic/angular/lazy';
import { CartService } from '../services/cart-service';
import { TransactionService } from '../services/transaction-service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
  standalone: false,
})
export class CartPage {

  constructor(
    public cartservice: CartService,
    private transactionservice: TransactionService,
    private router: Router,
    private animationCtrl: AnimationController
  ) { }

  confirmTransaction() {
    if (this.cartservice.items.length === 0) {
      return;
    }

    // 1. save the transaction (snapshot of the cart)
    this.transactionservice.add(this.cartservice.items, this.cartservice.getTotal());

    // 2. reduce the stock of every purchased product
    for (const item of this.cartservice.items) {
      item.product.stock -= item.qty;
    }

    // 3. empty the cart, then play the success animation
    this.cartservice.clear();
    this.playSuccessAnimation();
  }

  playSuccessAnimation() {
    const icon = document.querySelector('#successIcon') as HTMLElement;
    const animation = this.animationCtrl
      .create()
      .addElement(icon)
      .duration(800)
      .keyframes([
        { offset: 0, opacity: '0', transform: 'scale(0.3)' },
        { offset: 0.5, opacity: '1', transform: 'scale(1.3)' },
        { offset: 1, opacity: '1', transform: 'scale(1)' },
      ])
      .onFinish(() => {
        this.router.navigate(['/tabs/transactions']);
      });
    animation.play();
  }

}
